# Dlimans POS release rules
